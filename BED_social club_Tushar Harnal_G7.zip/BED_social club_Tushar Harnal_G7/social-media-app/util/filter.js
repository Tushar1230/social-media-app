const Filter = require("bad-words");

const filter = new Filter({ placeHolder: "X" });

module.exports = filter;
